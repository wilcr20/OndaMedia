import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { InicioPage } from '../pages/inicio/inicio';
import { NoticiasPage } from '../pages/noticias/noticias';
import { OnTelevisionPage } from '../pages/on-television/on-television';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { CanalesDeRadioPage } from '../pages/canales-de-radio/canales-de-radio';
import { NosotrosPage } from '../pages/nosotros/nosotros';
import { ContactoPage } from '../pages/contacto/contacto';
import { CentroDePrivacidadPage } from '../pages/centro-de-privacidad/centro-de-privacidad';
import { NoticiaPage } from '../pages/noticia/noticia';
import { EventosPage } from '../pages/eventos/eventos';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    InicioPage,
    NoticiasPage,
    OnTelevisionPage,
    TabsControllerPage,
    CanalesDeRadioPage,
    NosotrosPage,
    ContactoPage,
    CentroDePrivacidadPage,
    NoticiaPage,
    EventosPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    InicioPage,
    NoticiasPage,
    OnTelevisionPage,
    TabsControllerPage,
    CanalesDeRadioPage,
    NosotrosPage,
    ContactoPage,
    CentroDePrivacidadPage,
    NoticiaPage,
    EventosPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}