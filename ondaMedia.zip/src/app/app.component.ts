import { Component, ViewChild } from '@angular/core';
import { Platform, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { NosotrosPage } from '../pages/nosotros/nosotros';
import { ContactoPage } from '../pages/contacto/contacto';
import { CentroDePrivacidadPage } from '../pages/centro-de-privacidad/centro-de-privacidad';


import { InicioPage } from '../pages/inicio/inicio';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
    rootPage:any = InicioPage;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }
  goToNosotros(params){
    if (!params) params = {};
    this.navCtrl.setRoot(NosotrosPage);
  }goToContacto(params){
    if (!params) params = {};
    this.navCtrl.setRoot(ContactoPage);
  }goToCentroDePrivacidad(params){
    if (!params) params = {};
    this.navCtrl.setRoot(CentroDePrivacidadPage);
  }goToInicio(params){
    if (!params) params = {};
    this.navCtrl.setRoot(InicioPage);
  }
}
