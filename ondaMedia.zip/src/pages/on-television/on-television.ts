import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-on-television',
  templateUrl: 'on-television.html'
})
export class OnTelevisionPage {

  constructor(public navCtrl: NavController) {
  }
  
}
