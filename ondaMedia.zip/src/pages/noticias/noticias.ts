import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { NoticiaPage } from '../noticia/noticia';

@Component({
  selector: 'page-noticias',
  templateUrl: 'noticias.html'
})
export class NoticiasPage {

  constructor(public navCtrl: NavController) {
  }
  goToNoticia(params){
    if (!params) params = {};
    this.navCtrl.push(NoticiaPage);
  }
}
