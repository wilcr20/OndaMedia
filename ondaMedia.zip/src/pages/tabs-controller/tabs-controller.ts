import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CanalesDeRadioPage } from '../canales-de-radio/canales-de-radio';
import { EventosPage } from '../eventos/eventos';
import { InicioPage } from '../inicio/inicio';
import { NoticiasPage } from '../noticias/noticias';
import { EventosPage } from '../eventos/eventos';
import { CanalesDeRadioPage } from '../canales-de-radio/canales-de-radio';
import { OnTelevisionPage } from '../on-television/on-television';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {

  tab1Root: any = InicioPage;
  tab2Root: any = NoticiasPage;
  tab3Root: any = EventosPage;
  tab4Root: any = CanalesDeRadioPage;
  tab5Root: any = OnTelevisionPage;
  constructor(public navCtrl: NavController) {
  }
  goToCanalesDeRadio(params){
    if (!params) params = {};
    this.navCtrl.push(CanalesDeRadioPage);
  }goToEventos(params){
    if (!params) params = {};
    this.navCtrl.push(EventosPage);
  }
}
