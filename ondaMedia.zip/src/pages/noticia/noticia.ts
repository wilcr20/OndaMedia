import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-noticia',
  templateUrl: 'noticia.html'
})
export class NoticiaPage {

  constructor(public navCtrl: NavController) {
  }
  
}
