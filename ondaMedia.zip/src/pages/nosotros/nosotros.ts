import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-nosotros',
  templateUrl: 'nosotros.html'
})
export class NosotrosPage {

  constructor(public navCtrl: NavController) {
  }
  
}
