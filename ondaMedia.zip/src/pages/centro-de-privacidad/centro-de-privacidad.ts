import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-centro-de-privacidad',
  templateUrl: 'centro-de-privacidad.html'
})
export class CentroDePrivacidadPage {

  constructor(public navCtrl: NavController) {
  }
  
}
