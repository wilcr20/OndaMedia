import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-canales-de-radio',
  templateUrl: 'canales-de-radio.html'
})
export class CanalesDeRadioPage {

  constructor(public navCtrl: NavController) {
  }
  
}
